
class User < ApplicationRecord
  devise :database_authenticatable, :registerable,
         :recoverable, :rememberable, :validatable,
         :jwt_authenticatable, jwt_revocation_strategy: Devise::JWT::RevocationStrategies::Null

  enum role: { admin: 'admin', instructor: 'instructor', student: 'student' }

  has_many :courses, foreign_key: 'instructor_id'
  has_many :enrollments
  has_many :enrolled_courses, through: :enrollments, source: :course
  has_many :submissions
  has_many :discussion_topics
end
