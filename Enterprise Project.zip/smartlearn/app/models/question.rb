
class Question < ApplicationRecord
  belongs_to :quiz
end
