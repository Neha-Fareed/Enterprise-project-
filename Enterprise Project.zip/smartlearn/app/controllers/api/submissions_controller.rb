
class Api::SubmissionsController < ApplicationController
  before_action :authenticate_user!

  def create
    submission = Submission.create!(
      user: current_user,
      assignment_id: params[:submission][:assignment_id],
      content: params[:submission][:content]
    )
    render json: { message: 'Submission received', submission: submission }
  end

  def index
    render json: current_user.submissions
  end
end
