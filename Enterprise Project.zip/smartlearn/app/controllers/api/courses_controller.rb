
class Api::CoursesController < ApplicationController
  before_action :authenticate_user!

  def index
    render json: Course.all
  end

  def show
    course = Course.find(params[:id])
    render json: course
  end

  def enroll
    course = Course.find(params[:id])
    current_user.enrollments.create!(course: course)
    render json: { message: 'Enrolled successfully' }
  end
end
