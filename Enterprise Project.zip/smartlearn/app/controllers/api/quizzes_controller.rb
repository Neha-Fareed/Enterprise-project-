
class Api::QuizzesController < ApplicationController
  before_action :authenticate_user!

  def index
    course = Course.find(params[:course_id])
    render json: course.quizzes
  end

  def attempt
    quiz = Quiz.find(params[:id])
    score = 0
    quiz.questions.each do |q|
      answer = params[:answers][q.id.to_s]
      score += 1 if q.correct_answer == answer
    end
    render json: { score: score, total: quiz.questions.count }
  end
end
