
class Api::DiscussionTopicsController < ApplicationController
  before_action :authenticate_user!
  before_action :set_course

  def index
    render json: @course.discussion_topics
  end

  def create
    topic = @course.discussion_topics.create!(
      title: params[:title],
      body: params[:body],
      user: current_user
    )
    render json: topic
  end

  private

  def set_course
    @course = Course.find(params[:course_id])
  end
end
