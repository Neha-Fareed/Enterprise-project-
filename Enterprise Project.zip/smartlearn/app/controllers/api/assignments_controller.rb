
class Api::AssignmentsController < ApplicationController
  before_action :authenticate_user!

  def index
    course = Course.find(params[:course_id])
    render json: course.assignments
  end
end
