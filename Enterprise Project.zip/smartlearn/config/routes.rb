
Rails.application.routes.draw do
  namespace :api do
    namespace :auth do
      devise_for :users, path: '', controllers: {
        registrations: 'api/auth/registrations',
        sessions: 'api/auth/sessions'
      }
    end

    resources :courses, only: [:index, :show] do
      post 'enroll', on: :member
      resources :assignments, only: [:index]
      resources :quizzes, only: [:index] do
        post 'attempt', on: :member
      end
      resources :discussion_topics, only: [:index, :create]
    end

    resources :submissions, only: [:create, :index]
  end
end
