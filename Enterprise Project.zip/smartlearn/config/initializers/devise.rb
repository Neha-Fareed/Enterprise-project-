
config.jwt do |jwt|
  jwt.secret = Rails.application.credentials.devise[:jwt_secret_key]
  jwt.dispatch_requests = [['POST', %r{^/api/auth/login$}]]
  jwt.revocation_requests = [['DELETE', %r{^/api/auth/logout$}]]
  jwt.expiration_time = 1.day.to_i
end
